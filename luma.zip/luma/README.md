# LUMA

A little progress, every day. Local-first personal life system: Today, Planner, Routines, Goals, To-do, Progress, Settings.

- Zero build. `index.html` is the whole app (plus manifest and icons). No framework, no dependencies.
- Data lives in IndexedDB on the device (`repo` object in index.html). Accounts start blank.
- Routes use the URL hash (`#/today`, `#/planner`, ...), so refreshing any page works with no server rewrites.

## Deploy (Vercel)
Framework Preset: **Other**. Root Directory: repo root. Build Command, Install Command: empty. Output Directory: `.` (vercel.json already sets this). Production Branch: `main`.

## Connect Supabase later
Replace the `repoIDB` object with an object exposing the same five methods (`open, list, put, remove, clear`) backed by Supabase tables named goals, routines, sessions, tasks, settings (each row: `id`, `user_id default auth.uid()`, `data jsonb`, `updated_at`), enable Row Level Security (`user_id = auth.uid()`), add sign-in, and run a one-time import of local data (Me > Export or import produces the JSON).
